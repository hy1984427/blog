//
//  main.m
//  HelloWorld
//
//  Created by twer on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#ifdef NATIVEDRIVER
#import "NDNativeDriver.h"
#endif

int main(int argc, char *argv[])
{
    
    #ifdef NATIVEDRIVER
    [NDNativeDriver start];
    NSLog(@"-------------NDNativeDriver start-------------------");
    #endif
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }

}
